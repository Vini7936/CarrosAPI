package org.acme.exception;

public class CarroNotFoundException extends RuntimeException{
    public CarroNotFoundException(String s) {
    }
}
