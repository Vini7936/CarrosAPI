package org.acme.controllers;
import io.quarkus.security.identity.SecurityIdentity;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.jwt.Claims;
import io.smallrye.jwt.build.Jwt;


@Path("/auth")
@Produces(MediaType.TEXT_PLAIN)
@Consumes(MediaType.APPLICATION_JSON)

public class Login {

    @Inject
        SecurityIdentity securityIdentity;

    @POST
    @Path("/login")
    public Response login(LoginRequest loginRequest){
        if(securityIdentity.isAnonymous() || !securityIdentity.getPrincipal().getName().equals(loginRequest.getUsuario())){
            if("admin".equals(loginRequest.getUsuario()) && "senha".equals(loginRequest.getSenha())){
                String token = Jwt.issuer("http://localhost:8080/").upn(loginRequest.getUsuario()).groups("admin", "usuario").claim(Claims.birthdate.name(), "2025-05-10").sign();
                return Response.ok(token).build();
            }else if ("usuario".equals(loginRequest.getUsuario()) && "senha".equals(loginRequest.getSenha())){
                String token = Jwt.issuer("http://localhost:8080/").upn(loginRequest.getUsuario()).groups("usuario").sign();
                return Response.ok(token).build();
            }
        }
        return Response.status(Response.Status.UNAUTHORIZED).entity("Usuário ou senha inválidos").build();
    }
}
