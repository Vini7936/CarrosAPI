package org.acme.controllers;
import io.quarkus.security.Authenticated;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.entity.Carro;
import org.acme.exception.CarroNotFoundException;
import org.acme.services.CarroService;


import java.util.List;


@Path("/api/carro")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Authenticated
public class CarroController {

    @Inject
    CarroService carroService;

    @GET
    @PermitAll
    public Response retrieveCarros(){
        try{
            List<Carro> carros = carroService.findAllCarros();
            return Response.ok(carros).build();
        }catch (Exception e){
            e.printStackTrace();


        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Erro ao buscar carros.").build();
    }
}
    @POST
    @RolesAllowed("admin")
    @Transactional
    public Response addCarro(Carro carro){
        try {
           Carro newOrExistingCarro = carroService.addCarro(carro);
           return Response.status(Response.Status.CREATED).entity(newOrExistingCarro).build();
        }catch (IllegalArgumentException e){
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }catch (Exception e){
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Erro ao adicionar carro!").build();
        }
    }

    @PUT
    @Path("/{id}")
    @Transactional
    @RolesAllowed({"admin"})
    public Response updateCarro(@PathParam("id") Long id, Carro carro){
        try {
            Carro updateCarro = carroService.updateCarro(id, carro);
            return Response.ok(updateCarro).build();
        } catch (CarroNotFoundException e){
            return Response.status(Response.Status.NOT_FOUND).entity(e.getMessage()).build();
        }catch (IllegalArgumentException e){
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }catch (Exception e){
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Erro ao atualizar carro").build();
        }

    }

    @GET
    @Path("/{id}")
    @PermitAll
    public Response findCarroById(@PathParam("id")Long id){
        try{
            Carro carro =carroService.findById(id);
            return Response.ok(carro).build();
        }catch (CarroNotFoundException e){
            return Response.status(Response.Status.NOT_FOUND).entity(e.getMessage()).build();
        }catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Erro ao buscar carro!").build();
        }
    }

    @DELETE
    @Path("/{id}")
    @RolesAllowed("admin")
    @Transactional
    public Response deleteCarro(@PathParam("id")Long id){
        try{
            carroService.deleteCarro(id);
            return Response.noContent().build();
        }catch (Exception e){
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Erro ao excluir carro!").build();
        }


    }
}
