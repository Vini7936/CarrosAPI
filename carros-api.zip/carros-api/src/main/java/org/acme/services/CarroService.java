package org.acme.services;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.acme.entity.Carro;
import org.acme.exception.CarroNotFoundException;
import org.acme.repository.CarroRepository;

import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class CarroService {

    @Inject
    CarroRepository carroRepository;

    public List<Carro> findAllCarros(){
        return carroRepository.findAll().list();
    }

    @Transactional
    public Carro addCarro(Carro carro){
       if (carro == null || carro.getModelo() == null || carro.getFabricante() == null || carro.getAno() == null) {
       throw new IllegalArgumentException("Dados inválidos ou incompletos");
       }

       Optional<Carro> existingCarro = carroRepository.find("modelo = ?1 and fabricante = 2? and ano = ?3", carro.getModelo(), carro.getFabricante(), carro.getAno()).firstResultOptional();

       if (existingCarro.isPresent()){
           System.out.println("Carro duplicado:" + existingCarro.get().getId());
           return existingCarro.get();
       }else {
           carroRepository.persist(carro);
           return carro;
       }
    }

    public Carro findById(Long id){
        return carroRepository.findByIdOptional(id).orElseThrow(() -> new CarroNotFoundException("Carro não encontrado!"));
    }


    @Transactional
    public Carro updateCarro(Long id, Carro carroDetalhe) {

        var alterarCarro = findById(id);

        if(carroDetalhe.getModelo() != null){
            alterarCarro.setModelo(carroDetalhe.getModelo());
        }


        carroRepository.persist(alterarCarro);
        return alterarCarro;
    }


@Transactional
    public void deleteCarro(Long id) {
       carroRepository.findByIdOptional(id).ifPresent(carroRepository::delete);

    }
}
